/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.currencyconverter;

/**
 *
 * @author PC
 */
public class CurrencyConverter {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
